// Demo For PERSONAL USE, or for teachers for use in their classrooms only, but any donation are very appreciated :)
Paypal Account for Donation: https://www.paypal.me/DeriKurnia

// For commercial use license, please purchase a license here: 
Graphicriver : https://graphicriver.net/user/trim_studio/portfolio
Fontbundles : https://fontbundles.net/trim-studio
Creativefabrica : https://www.creativefabrica.com/designer/trim-studio/
Thehungryjpeg : https://thehungryjpeg.com/store/trim-studio

// Follow Us
Instagram : https://www.instagram.com/id.trimstudio
Pinterest : https://id.pinterest.com/trimstudioo/

// Demo Version
Pixelify : https://pixelify.net/artist/trim-studio
Dafont : https://www.dafont.com/trim-studio.d7467

Thank you .
-Trim Studio -
